package com.java.dao;

import java.util.Iterator;
import java.util.TreeSet;



import com.java.model.Book;



public class Database {
     
    TreeSet<Book> bookList = new TreeSet<>();
    
     public Database() {
         
        Book b1 = new Book(101,"gfdt","hgt",500);
        Book b2 = new Book(102,"gfdu","xgt",550);
        Book b3 = new Book(103,"dfg","rtyh",600);
        Book b4 = new Book(104,"gfrt","ertg",700);
        
        bookList.add(b1);
        bookList.add(b2);
        bookList.add(b3);
        bookList.add(b4);
    
    }
    



   public Database(TreeSet<Book> bookList) {
        super();
        this.bookList = bookList;
    }



   public TreeSet<Book> getBookList() {
        return bookList;
    }



   public void setBookList(TreeSet<Book> bookList) {
        this.bookList = bookList;
    }
    
    
}
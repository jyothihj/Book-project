package com.java.service;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;



import com.java.dao.Database;
import com.java.model.Book;



public class BookService {
    Database d = new Database();
    
    
    public void viewBooks()
    {
            TreeSet<Book> t = d.getBookList();
            Iterator<Book> itr = t.iterator();
            
            while(itr.hasNext())
            {
                System.out.println(itr.next());
            }
    }
    
    public void addBook()
    {   
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter book details ");
        
        
        System.out.println("Enter book id ");
        int bookId = sc.nextInt();
        System.out.println("Enter book name ");
        String name = sc.next();
        System.out.println("Enter name of the author ");
        String author = sc.next();
        System.out.println("Enter book price ");
        int cost = sc.nextInt();
        
        Book b = new Book(bookId,name,author,cost);
        
        TreeSet<Book> tr = d.getBookList();
        tr.add(b);
        
    }
    
    public void deleteBook()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter id of the book you want to delete ");
        int id = sc.nextInt();
        TreeSet<Book> tr = d.getBookList();
        deleteBook(tr,id);
        
    }
    
    public void deleteBook(TreeSet<Book> t, int bookId)
    {
        Iterator<Book> itr = t.iterator();
        
        while(itr.hasNext())
        {
            Book b = itr.next();
            if(b.getBookId() == bookId)
                { t.remove(b); break;}
        }
    }
    
    public void searchBookByName ()
    {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the name of the book ");    
        String name = sc.next();
        
        TreeSet<Book> t = d.getBookList();
        Iterator<Book> itr = t.iterator();
        
        while(itr.hasNext())
        {
            Book b = itr.next();
            if(b.getName().equals(name))
              { System.out.println(b); break;}
        }
    }



}
